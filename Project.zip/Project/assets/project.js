document.getElementById("save").addEventListener("click", display);

function display() {
    alert("Terima Kasih Sudah Mendaftar\n" + "'''Selamat Bergabung Dengan Kegiatan Kami'''")
}

var a = document.getElementById("mouse");
a.addEventListener("mouseover", myfunction);
a.addEventListener("mouseout",out);
function myfunction() {
    document.getElementById("show").style.color = '#5F7161';
}
function out() {
    document.getElementById("show").style.color = '#EFEAD8';
}